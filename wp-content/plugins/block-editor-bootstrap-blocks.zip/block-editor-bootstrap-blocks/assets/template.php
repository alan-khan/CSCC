<?php
/*
 * Template Name: Bootstrap
 */
?>

<?php get_header() ?>
<?php the_post() ?>

<div class="container">
	<?php the_content() ?>
</div>

<?php get_footer() ?>